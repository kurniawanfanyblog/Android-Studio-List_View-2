package com.uty.listviewfood

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uty.listviewfood.adapter.listfood
import com.uty.listviewfood.model.food
import com.uty.listviewfood.model.datafood

class MainActivity : AppCompatActivity() {
    private lateinit var rvfood: RecyclerView
    private var list: ArrayList<food> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvfood = findViewById(R.id.rv_food)
        rvfood.setHasFixedSize(true)
        list.addAll(datafood.listfood)
        showfoodList()
    }

    private fun showfoodList(){
        rvfood.layoutManager = LinearLayoutManager(this)
        rvfood.adapter = listfood(this,list){
            Toast.makeText(this,it.detail,Toast.LENGTH_SHORT).show();
        }
    }
}
