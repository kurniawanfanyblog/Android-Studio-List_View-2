package com.uty.listviewfood.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uty.listviewfood.R
import com.uty.listviewfood.model.food
import com.uty.listviewfood.model.datafood.listfood

class listfood (private val context: Context, private val food: ArrayList<food>, private val listener: (food) -> Unit)
    : RecyclerView.Adapter<listfood.ViewHolder>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): listfood.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_food, parent, false))

    }

    override fun getItemCount(): Int {
        return listfood.size
    }

    override fun onBindViewHolder(holder: listfood.ViewHolder, position: Int) {
        holder.bindfood(food[position], listener)

    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvName: TextView = view.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = view.findViewById(R.id.tv_item_detail)
        var imgPoster: ImageView = view.findViewById(R.id.img_item_poster)

        fun bindfood(food: food, listener: (food) -> Unit){
            tvName.text = food.name
            tvDetail.text = food.detail
            Glide.with(itemView.context)
                .load(food.poster)
                .into(imgPoster)

            
        }
    }
}