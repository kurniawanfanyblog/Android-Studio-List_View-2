package com.uty.listviewfood.model

import com.uty.listviewfood.R

object datafood {
    private val nama_food = arrayOf(
        "Bola Ubi",
        "Churros",
        "Dadar Gulung",
        "Gudeg",
        "Ikan Tauco",
        "Nagasari Labu",
        "Nasi Goreng",
        "Pie Buah",
        "Pisang Gapit",
        "Srikaya Roti"
    )

    private val detail = arrayOf(
        "Bola ubi adalah cemilan terlezat didunia",
        "Churros adalah makanan",
        "Dadar Gulung adalah telur yang digulung",
        "Gudeg Khas Yogyakarta",
        "Ikan Tauco mantepppe poll",
        "Nagasari manakanan manis kayak kamu",
        "Nasi goreng adalah nasi dingin",
        "Pie Buah seger eee",
        "Pisang mantul banget",
        "Srikaya roti adalah roti yang ternikmat di semua galaxy"
    )

    private val foodPoster = intArrayOf(
        R.drawable.bolaubi,
        R.drawable.churros,
        R.drawable.dadar,
        R.drawable.gudeg,
        R.drawable.tauco,
        R.drawable.naga,
        R.drawable.nasgor,
        R.drawable.pie,
        R.drawable.pisang,
        R.drawable.srikaya

    )

    val listfood : ArrayList<com.uty.listviewfood.model.food>
        get(){
            val list = arrayListOf<com.uty.listviewfood.model.food>()
            for (position in nama_food.indices){
                val food = com.uty.listviewfood.model.food()
                food.name = nama_food[position]
                food.detail = detail[position]
                food.poster = foodPoster[position]
                list.add(food)
            }
            return list
        }
}