package com.uty.listviewfood.model

class food {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}